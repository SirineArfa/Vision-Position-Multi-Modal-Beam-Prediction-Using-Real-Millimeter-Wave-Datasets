
Each beam is measured with 211 directions that are equally spaced between 0 to 180 degree.

Just run 'plot_built_in_codebook_beams.m' which will plot you the measured beam patterns.